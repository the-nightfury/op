<?php 
	
	
	include_once("config.php");
	include_once('templates/header.php');
	
	
	$file_error_1 = $file_error = $upload_status_1= $upload_status_2= false;
	
	
	if (isset($_POST['update'])){
		
		$filename  = "status.csv";
		$filename1  = "pfin_status.csv";
		
		
		$file   = fopen($filename, "r");
		$file1  = fopen($filename1, "r");
		
		
		$sql = $sql1 =  "";
		
		if($file){
			while (($getData = fgetcsv($file)) !== FALSE)
			{
				
				$sql .= "INSERT INTO `status` (`app_id`, `app`, `production_url`, `inputs`, `app_status`, `db_status`) VALUES ('".$getData[1]."','".$getData[2]."','".$getData[3]."','".$getData[4]."','".$getData[5]."','".$getData[6]."');";
			}
			if($sql != ""){
				$sql = "TRUNCATE TABLE `status`;ALTER TABLE `status` AUTO_INCREMENT = 1;" .$sql;
			}
			}else{
			$file_error = " Unable to open the file";
		}
		
		
		if($file1){
			
			while (($getData1 = fgetcsv($file1)) !== FALSE)
			{
				$sql1 .= "INSERT INTO `pfin_status` (`app_id`, `status_id`, `status_code`) VALUES (".$getData1[1].",'".$getData1[2]."','".$getData1[3]."');";
			}
			
			if($sql1 != ""){
				$sql1 = "TRUNCATE TABLE `pfin_status`;ALTER TABLE `pfin_status` AUTO_INCREMENT = 1;" .$sql1;
			}
			
		}
		else{
			$file_error_1 = " Unable to open the file";
		}
		
		
		
		
		$sql =  $sql.$sql1;
		
		if ($mysqli->multi_query($sql)) {
			$upload_status_1 = true;
		}else
		{
			$upload_status_1 = "error";
			
		}
		
		
		fclose($file);	
	}
	
?>
<nav class="navbar is-fixed-top has-shadow">
	<div class="navbar-brand">
		<a class="navbar-item" href="index.php">
			<img src="images/1.png" alt="" width="112" height="110" style="max-height:64px;">
		</a>
		<div class="navbar-burger burger" data-target="navbarExampleTransparentExample">
			<span></span>
			<span></span>
			<span></span>
		</div>
	</div>
	
	<div id="navbarExampleTransparentExample" class="navbar-menu">
		<div class="navbar-end">
			<div class="navbar-item">
				<div class="field is-grouped">
					<p class="control">
						<a class="button" href="index.php" >
							<span>
								BACK
							</span>
						</a>
					</p>
				</div>
			</div>
		</div>
	</div>
</nav>

<section class="section">
	<div class="container">
		<div class="card-content">
			<form action="upload.php" method="POST">
				<div class="card">
					<div class="card-content has-text-centered">
						<h4 class="subtitle is-2 bd-feature-title">
							Update
						</h4>
						<p class="subtitle is-3">
							<?php
								
								if ($upload_status_1== true){
									
									
								?>
								<article class="message is-success">
									<div class="message-header">
										<p>Success</p>
										<button class="delete" aria-label="delete"></button>
									</div>
									<div class="message-body">
										Status Database Updated
									</div>
								</article>
								
								<?php
								}
								else if ($upload_status_1 == "error"){
									
								?>
								
								<article class="message is-danger">
									<div class="message-header">
										<p>Error</p>
										<button class="delete" aria-label="delete"></button>
									</div>
									<div class="message-body">
										Error updating status database;
									</div>
								</article>
								<?php
									
								}
								
								if ($file_error){
									
								?>
								<article class="message is-danger">
									<div class="message-header">
										<p>Error</p>
										<button class="delete" aria-label="delete"></button>
									</div>
									<div class="message-body">
										Error Opening status file;
									</div>
								</article>
								
								<?php
								}
								
								
								
								
								if ($file_error_1){
									
								?>
								<article class="message is-danger">
									<div class="message-header">
										<p>Error</p>
										<button class="delete" aria-label="delete"></button>
									</div>
									<div class="message-body">
										Error Opening pfin status file;
									</div>
								</article>
								
								<?php
								}
								
							?>
							
						</p>
					</div>
					<footer class="card-footer">
						<p class="card-footer-item">
							<span>
								<input type="submit" name="update" class="button is-primary" value="Update">
							</span>
						</p>
					</footer>
				</div>
				
			</form>
			
		</div>
	</div>
</section>

<?php 
	include_once('templates/footer.php');
?>	