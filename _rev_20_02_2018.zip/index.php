
<?php 
	
	include_once('templates/header.php');
	
?>

<nav class="navbar is-fixed-top has-shadow">
  <div class="navbar-brand">
    <a class="navbar-item" href="index.php">
      <img src="images/1.png" alt="" width="112" height="110" style="max-height:64px;"> 
    </a>
   
  </div>

</nav>

<section class="section">
    <div class="container">
	
		<div class="card-content">
			<form action="view.php" method="GET">
				
				
				
				
				<div class="card">
					<div class="card-content">
						<div class="columns">
							<div class="column is-3">
								<h4 class="subtitle is-4 bd-feature-title">
									Portfolio
								</h4>
							</div>
							<div class="column is-9" style="height: 6rem;">
								<div class="level-item">
									<span class="select">
										<select  name="portfolio">
											<option value="-">-</option>
											<option value="p">Provider</option>
										</select>
									</span>
								</div>
							</div>
						</div>
						
						<div class="columns">
							<div class="column is-3">
								<h4 class="subtitle is-4 bd-feature-title">
									Product Area
								</h4>
							</div>
							<div class="column is-9" style="height: 6em;">
								<div class="level-item">
									<span class="select">
										<select  name="product_area">
											<option value="-">-</option>
											<option value="alt_cont">Alternative Contracting</option>
											<option value="pricing">Pricing</option>
											<option value="provider">Provider</option>
										</select>
									</span>
								</div>
							</div>
						</div>
					</div>
					<footer class="card-footer">
						<p class="card-footer-item">
							<span>
								<input type="submit" class="button is-primary" text="Continue"/>
							</span>
						</p>
					</footer>
				</div>
				
				
				
				
				
				
				<?php
					
					/*
						<label for="portfolio">Portfolio</label>
						<select id="portfolio" name="portfolio">
						<option value="-">-</option>
						<option value="p">Provider</option>
						</select>	
						<label for="product_area">Product Area</label>
						<select id="product_area" name="product_area">
						<option value="-">-</option>
						<option value="alt_cont">Alternative Contracting</option>
						<option value="pricing">Pricing</option>
						<option value="provider">Provider</option>
						</select>
						
					*/
				?>
				
				
			</form>
			
		</div>
	</div>
</section>

<?php 
	
	include_once('templates/footer.php');
	
?>