<!DOCTYPE html>
<html class="has-navbar-fixed-top">
	<head>
		<title>Portal</title>
		<meta charset="utf-8">
		<link rel="stylesheet" href="css/bulma.min.css">
		<script defer src="js/all.js"></script>
	</head>
	
	
	<style>
		
		body{
		background:#FAFAFA url(images/bg01.png);
		min-height: 100%;
		}
		
		html{
		height: 100%;
		}
		
		#table1 {
		font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
		border-collapse: collapse;
		width: 100%;
			box-shadow: 0px 1px 9px 1px #d6d6d6;
		background: #FFF;
		}
		
		#table1 td, #table1 th {
		border: 1px solid #ddd;
		padding: 8px;
		}
		
		#table1 tr:nth-child(even){background-color: #f2f2f2;}
		
		#table1 tr:hover {background-color: #ddd;}
		
		#table1 th {
		padding-top: 12px;
		padding-bottom: 12px;
		text-align: left;
		background-color: #2196F3;
		color: white;
	
		}
	
		.options_v{
		max-width:500px;
		margin:0 auto;
		border:1px solid  #CCC;
		padding:10px;
		background:#f9f9f9;
		border-radius:10px;
		}
		._active{
		background:#4CAF50;
		}
		
		._inactive{
		background:#F44336;
		}
		._unknown_active{
		background:#a2a2a2;
		}
	</style>
	
<body>