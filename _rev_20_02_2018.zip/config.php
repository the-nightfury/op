<?php
	
	$mysqli = new mysqli("localhost", "root", "", "va_");
	
	if ($mysqli->connect_errno) {
		
	    echo "There was some problem connecting to database ";
		echo "<br>".$mysqli->connect_errno;
		exit();
	}
	
	
	
	
	
?>