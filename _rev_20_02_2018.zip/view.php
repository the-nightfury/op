<?php
	
    include_once("config.php");
	function resultToArray($result) {
		$rows = array();
		while($row = $result->fetch_assoc()) {
			$rows[] = $row;
		}
		return $rows;
	}
	
	
   	function getData($mysqli,$bundle=null,$shore=null){
		
		$w_bundle  =  "";
	    if ($bundle === "p"){
			$w_bundle  = "AND portfolio = 'provider' ";
		}
		else if ($bundle === "p") {
			$w_bundle  = "AND portfolio = 'sample'  ";
		}
		
		
		$s_shore  =  "";
	    if ($shore === "alt_cont"){
			$s_shore  = "AND product_area = 'Alternative Contracting'  ";
		}
		else if ($shore === "pricing") {
			$s_shore  = "AND product_area = 'Pricing'  ";
			}else if ($shore === "provider") {
			$s_shore  = "AND product_area = 'Provider'  ";
		}
		
		$sql      = "SELECT `a`.`id`,`a`.`portfolio`,`a`.`product_area`,`a`.`application_name`,`a`.`on_off_shore`,`a`.`ui_online`,`a`.`db`,`a`.`server_status`,`a`.`web_services`,`a`.`mainframe`,(select GROUP_CONCAT(`db_status`) as `sfftatus_`
		from `status` as `c` where `c`.`app_id` =  `a`.`id`)  as `_db_status`,(select GROUP_CONCAT(`app_status`) as `sfftatus_`
		from `status` as `c` where `c`.`app_id` =  `a`.`id`)  as `_app_status`,(CASE 
		WHEN `a`.`id` = 10
		THEN 
		(SELECT GROUP_CONCAT(`p_s`.`status_id`) FROM `pfin_status` as `p_s` where `a`.`id` = `p_s`.`app_id` AND `status_code`  = 'Not Operational')
		END 
		) as `_mainframe`
		
		FROM `app`as `a`
		
		WHERE 1 $w_bundle  $s_shore  ";
		if($result = $mysqli->query($sql)){
			$rows  = resultToArray($result);
			echo "<br><br><div class=\"\" style=\"margin:0 auto;\">";
			if (count($rows) > 0 ){
				echo "<table id=\"table1\" class=\"\" style=\"margin:0 auto;\">";
				echo "<thead><th>Portfolio</th><th>Product Area</th><th>Application Name</th><th>Overall <br>Application Status</th><th>Database Status</th><th>UI 
				Online Status</th></thead>";
				foreach($rows  as $row => $values){
					echo "<tr>";
					echo "<td>".$values['portfolio']."</td>";
					echo "<td>".$values['product_area']."</td>";
					echo "<td>".$values['application_name']."</td>";
					
					
					$default_value_db = "-";
					$default_value_app = "-";
					
					$app_class = $db_class     = 'class="_unknown_active"';
					
					
					$_db_status  = explode(",",$values['_db_status']);
					$_app_status = explode(",",$values['_app_status']);
					
				    if(in_array("Down",$_db_status)){
						$default_value_db  = "Down";
						$db_class          = 'class="_inactive"';
					}
					else if(in_array("Up",$_db_status)){
						$db_class ='class="_active"';
						$default_value_db  = "Up";
					}
					
					
					
					if(in_array("Down",$_app_status)){
						$default_value_app  = "Down";
						$app_class ='class="_inactive"';
						
					}
					else if(in_array("Up",$_app_status)){
						$app_class ='class="_active"';
						$default_value_app  = "Up";
					}
					
					
					$_data_view = '';
					$_mainframe_status = true;
					$mf_class ='class="_unknown_active"';
					if($values['_mainframe']){
						$mf_class ='class="_inactive"';
					    $_data_view = '';
						$_data = explode(",",$values['_mainframe']);
						if(count($_data) > 0){
							$_mainframe_status = false;
						}
						
						foreach($_data as $data_){
							$_data_view .= $data_."<br>";
						}
					}
					else if($values['_mainframe'] == 'NULL') {
						$mf_class ='class="_unknown"';
					}
					
					if(!$_mainframe_status ){
						$default_value_db = $default_value_app = "Down";
					    $app_class	= $db_class          = 'class="_inactive"';
						
					}
					
					
					$overall_status = "-";
					$overall_class = 'class="_unknown_active"';
					if($default_value_db == "Down" || $default_value_app == "Down"){
			    		$overall_status = "Down";
						$overall_class = 'class="_inactive"';
						}else if($default_value_db == "Up" && $default_value_app == "Up"){
				    	$overall_status = "Up";
						$overall_class = 'class="_active"';
					}
					
					
					echo "<td ".$overall_class.">".$overall_status."</td>";
					
					echo "<td ".$db_class.">".$default_value_db."</td>";
					
					echo "<td ".$app_class.">".$default_value_app."<br>".$_data_view."</td>";
					
					echo "</tr>";
				}
				
				echo "</table>";
			}
			else 
			
			{
				echo "<div class=\"no-content-a\">No events found</div>";
			}
			echo "<div class=\"clearfix\"></div>";
			
			echo "</div>";
			
			$result->free();
		}
	}
	
?>
<?php 
	
	include_once('templates/header.php');
	
?>

<nav class="navbar is-fixed-top has-shadow">
	<div class="navbar-brand">
		<a class="navbar-item" href="index.php">
			<img src="images/1.png" alt="" width="112" height="110" style="max-height:64px;">
		</a>
		<div class="navbar-burger burger" data-target="navbarExampleTransparentExample">
			<span></span>
			<span></span>
			<span></span>
		</div>
	</div>
	
	<div id="navbarExampleTransparentExample" class="navbar-menu">
		<div class="navbar-end">
			<div class="navbar-item">
				<div class="field is-grouped">
					<p class="control">
						<a class="button" href="index.php" >
							<span>
								BACK
							</span>
						</a>
					</p>
				</div>
			</div>
		</div>
	</div>
</nav>

<section class="section">
    <div class="container">
		<a class="button" href="upload.php" >
			<span>
				Update
			</span>
		</a>
		
		<?php
			
			$b=$s=null;
			if(isset($_GET['portfolio'])){
				$b=$_GET['portfolio'];
			} 
			
			if(isset($_GET['product_area'])){
				$s=$_GET['product_area'];
			}
			
			getData($mysqli,$b,$s);
		?>
	</div>
</section>
<?php 
	include_once('templates/footer.php');
?>


